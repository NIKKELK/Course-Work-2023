package com.example.rschircoursework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsChIrCourseWorkApplicationTests {

    @Test
    void contextLoads() {
    }

}
