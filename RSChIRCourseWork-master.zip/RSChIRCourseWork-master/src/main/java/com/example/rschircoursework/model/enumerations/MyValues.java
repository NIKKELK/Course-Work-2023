package com.example.rschircoursework.model.enumerations;

public final class MyValues {
    public static final String EMAILSERVER = "spring-test-server@yandex.ru";
    public static final String EMAILMENEGER = "sokol.izberkuta@yandex.ru";
}
