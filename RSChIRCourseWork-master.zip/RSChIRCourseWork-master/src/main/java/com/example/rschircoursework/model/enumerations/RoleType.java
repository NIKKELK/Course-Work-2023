package com.example.rschircoursework.model.enumerations;

public enum RoleType {
    ADMIN,
    USER
}
