package com.example.rschircoursework.model.dao;



import com.example.rschircoursework.model.entity.ItemType;
import org.springframework.stereotype.Repository;


@Repository
public interface IItemTypeRepository extends IAbstractRepository<ItemType> {
}
