package com.example.rschircoursework.model.dao;


import com.example.rschircoursework.model.entity.Pet;
import org.springframework.stereotype.Repository;

@Repository
public interface IPetRepository extends IAbstractRepository<Pet> {
}
