package com.example.rschircoursework.services;

import com.example.rschircoursework.model.entity.ItemType;

public interface IItemTypeService extends IAbstractService<ItemType> {
}
