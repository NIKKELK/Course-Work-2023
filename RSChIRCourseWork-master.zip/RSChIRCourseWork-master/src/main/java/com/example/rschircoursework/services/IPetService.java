package com.example.rschircoursework.services;


import com.example.rschircoursework.model.entity.Pet;

public interface IPetService extends IAbstractService<Pet>{
}
