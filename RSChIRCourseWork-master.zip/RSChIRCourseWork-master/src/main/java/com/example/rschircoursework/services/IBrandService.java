package com.example.rschircoursework.services;

import com.example.rschircoursework.model.entity.Brand;

public interface IBrandService extends IAbstractService<Brand>{
}
