package com.example.rschircoursework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RsChIrCourseWorkApplication {

    public static void main(String[] args) {
        SpringApplication.run(RsChIrCourseWorkApplication.class, args);
    }

}
