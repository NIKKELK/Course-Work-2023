package com.example.rschircoursework.model.dao;

import com.example.rschircoursework.model.entity.Brand;
import org.springframework.stereotype.Repository;

@Repository
public interface IBrandRepository extends IAbstractRepository<Brand>{
}
